﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TelegramBot.Entities
{
    internal class Rate
    {
        public string Name { get; set; }
        public double Value { get; set; }
    }
}
